from selenium.common.exceptions import WebDriverException
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains

class SearchResult:
    load_more_xpath = "//div[@class='full-screen-load-more-container visible']"
    load_more_invisible_xpath = "//div[@class='full-screen-load-more-container not-visible']"

    creative_count_xpath = "//div[@class='creative-count']/span"
    creative_actual_adv_xpath = "//div[@class='masonry-container show']/div"
    creative_actual_adv_count = 0
    creativeCountVal = 0

    random_brand_xpath = "//a[contains(.,'Random Brand')]"
    brand_header_xpath = "//span[@class='page-type']"
    brand_header_text = ""
    changed_brand_header_text = ""

    creative_container_xpath = "//div[@class='er-creative-container'][1]"
    share_link_xpath = "//a[contains(.,'Share')]"
    share_link_present = False


    def __init__(self, driver):
        self.driver = driver
    def searchResult(self):
        wait = WebDriverWait(self.driver, 10)
        creativeCountText = wait.until(EC.presence_of_element_located((By.XPATH, self.creative_count_xpath)))
        self.creativeCountVal = creativeCountText.text.split()[0]
        load_more_visible = self.driver.find_elements_by_xpath(self.load_more_xpath)
        load_more_invisible = self.driver.find_elements_by_xpath(self.load_more_invisible_xpath)
        if len(load_more_visible) > 0:
            while len(load_more_visible) > 0:
                self.driver.implicitly_wait(10)
                # self.driver.execute_script("arguments[0].scrollIntoView();", load_more_visible)
                # WebDriverWait(self.driver, 10)
                # load_more_visible[0].click()
                ActionChains(self.driver).move_to_element(load_more_visible[0]).click(load_more_visible[0]).perform()
                WebDriverWait(self.driver, 10)
                load_more_visible = self.driver.find_elements_by_xpath(self.load_more_xpath)

            creative_actual_adv = self.driver.find_elements_by_xpath(self.creative_actual_adv_xpath)
            self.creative_actual_adv_count = len(creative_actual_adv)
        elif len(load_more_invisible) > 0:
            WebDriverWait(self.driver, 10)
            creative_actual_adv = self.driver.find_elements_by_xpath(self.creative_actual_adv_xpath)
            self.creative_actual_adv_count = len(creative_actual_adv)


    def randomBrand(self):
        wait = WebDriverWait(self.driver, 10)
        header_ele = wait.until(EC.presence_of_element_located((By.XPATH, self.brand_header_xpath)))
        self.brand_header_text = header_ele.text
        randomBrand_ele = wait.until(EC.presence_of_element_located((By.XPATH, self.random_brand_xpath)))
        self.driver.execute_script("arguments[0].scrollIntoView();", randomBrand_ele)
        self.driver.execute_script("arguments[0].click();", randomBrand_ele)
        WebDriverWait(self.driver, 10)
        changed_header_ele = wait.until(EC.presence_of_element_located((By.XPATH, self.brand_header_xpath)))
        self.changed_brand_header_text = changed_header_ele.text

    def share_link(self):
        wait = WebDriverWait(self.driver, 10)
        creative_container_ele = wait.until(EC.presence_of_element_located((By.XPATH, self.creative_container_xpath)))
        action = ActionChains(self.driver)
        action.move_to_element(creative_container_ele).perform()
        WebDriverWait(self.driver, 10)
        shareLink = self.driver.find_element_by_xpath(self.share_link_xpath)
        WebDriverWait(self.driver, 10)
        try:
            shareLink.click()
            self.share_link_present = True
        except WebDriverException:
            print
            "Element is not clickable"







