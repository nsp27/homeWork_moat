from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

class LandingPage:
    autoComplete_box_xpath = "//input[@id='adsearch-input']"
    dropdown_elements_xpath = "//div[@class='auto-complete-text']/span"

    def __init__(self,driver):
        self.driver = driver

    def autoComplete(self, inputText):
        wait = WebDriverWait(self.driver, 10)
        ele = wait.until(EC.presence_of_element_located((By.XPATH, self.autoComplete_box_xpath)))
        self.driver.execute_script("arguments[0].scrollIntoView();", ele)
        ele.click()
        ele.clear()
        ele.send_keys(inputText)
        ele.click()
        wait.until(EC.presence_of_element_located((By.XPATH, self.dropdown_elements_xpath)));
        searched_ele = self.driver.find_elements_by_xpath(self.dropdown_elements_xpath)
        # searched_ele = self.driver.find_elements_by_xpath(self.dropdown_elements_xpath)
        self.elements = []
        for element in searched_ele:
            # print(element.text)
            self.elements.append(element.text)

    def Select_item(self, inputText):
        searched_term_drpdown_xpath = '// span[text() = "' + inputText + '"]'
        print(searched_term_drpdown_xpath)
        wait = WebDriverWait(self.driver, 10)
        searchEle = wait.until(EC.presence_of_element_located((By.XPATH, searched_term_drpdown_xpath)))
        self.driver.execute_script("arguments[0].scrollIntoView();", searchEle)
        # searched_term = driver.find_element_by_xpath("// span[text() = 'Saturn']")
        searchEle.click()
