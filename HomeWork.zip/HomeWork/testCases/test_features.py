import pytest
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from pageObjects.LandingPage import LandingPage
from utilities.readProperties import ReadConfig
from pageObjects.searchResult import SearchResult
# from utilities.customLogger import LogGen
import time

class Test_Home_work:
#### getting data from config file ######
    base_url = ReadConfig.getAppURL()

##### User input #########
    inputText = "Saturn"
    searchStrings = ["Saturn", "Saturday's Market", "Krux"]
##### User input #########

########### ******* Start AutoComplete Test ********** ###############
    def test_autoComplt(self, setUp):

        self.driver = setUp
        self.driver.get(self.base_url)
        WebDriverWait(self.driver, 10)
        self.land_page = LandingPage(self.driver)
        self.land_page.autoComplete(self.inputText)
        if self.inputText in self.land_page.elements:
            self.driver.close()
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"Failed_test_autoComplt.png")
            self.driver.close()
            assert False
########### ******* End of AutoComplete Test ********** ###############

########### ******* Starting search validation Test ********** ########
    def test_search_validation(self, setUp):
        lst_status = []
        for texts in self.searchStrings:
            self.driver = setUp
            self.driver.get(self.base_url)
            WebDriverWait(self.driver, 10)
            self.land_page = LandingPage(self.driver)
            self.land_page.autoComplete(texts)
            self.land_page.Select_item(texts)
            time.sleep(5)
            self.srchPage = SearchResult(self.driver)
            self.srchPage.searchResult()
            if int(self.srchPage.creativeCountVal) == self.srchPage.creative_actual_adv_count:
                lst_status.append("Pass")
            else:
                self.driver.save_screenshot(".\\Screenshots\\" + "Failed_test_search_validation.png")
                lst_status.append("Fail")
        print(lst_status)
        if "Fail" not in lst_status:
            self.driver.close()
            assert True
        else:
            self.driver.close()
            assert False
########### ******* End of search validation Test ********** ########

########### ******* Starting Random Brand validation Test **** ######
    def test_randomBrand(self,setUp):
        self.driver = setUp
        self.driver.get(self.base_url)
        WebDriverWait(self.driver, 10)
        self.land_page = LandingPage(self.driver)
        self.land_page.autoComplete(self.inputText)
        self.land_page.Select_item(self.inputText)
        self.srchPage = SearchResult(self.driver)
        self.srchPage.randomBrand()
        print(self.srchPage.brand_header_text)
        print(self.srchPage.changed_brand_header_text)
        if self.srchPage.brand_header_text != self.srchPage.changed_brand_header_text:
            self.driver.close()
            print("Random brand is working")
            assert True
        else:
            self.driver.close()
            print("Random brand is not working")
            self.driver.save_screenshot(".\\Screenshots\\" + "Failed_test_randomBrand.png")
            assert False
########### ******* End Of Random Brand validation Test **** ######

########### ******* Starting Of Share Ad validation Test **** ######
    def test_shareAd(self, setUp):
        self.driver = setUp
        self.driver.get(self.base_url)
        WebDriverWait(self.driver, 10)
        self.land_page = LandingPage(self.driver)
        self.land_page.autoComplete(self.inputText)
        self.land_page.Select_item(self.inputText)
        self.srchPage = SearchResult(self.driver)
        self.srchPage.share_link()
        if(self.srchPage.share_link_present == True):
            self.driver.close()
            assert True
        else:
            self.driver.close()
            self.driver.save_screenshot(".\\Screenshots\\" + "Failed_test_shareAd.png")
            assert False
########### ******* End Of Share Ad validation Test **** ######