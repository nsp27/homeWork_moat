from selenium import webdriver
import pytest

@pytest.fixture()
def setUp(browser):
    if browser == 'chrome':
        driver = webdriver.Chrome()
        driver.maximize_window()
    elif browser == 'firefox':
        driver = webdriver.Firefox()
        driver.maximize_window()
    else:
        driver = webdriver.Ie()
        driver.maximize_window()
    return driver


def pytest_addoption(parser):
    parser.addoption("--browser")

@pytest.fixture()
def browser(request):
    return request.config.getoption("--browser")

###### pytest HTML report ################
### hooks adding environment into html report##
def pytest_configure(config):
    config._metadata['Project'] = 'Home Work'
    config._metadata['Module Name'] = 'Moat Website functionality'
    config._metadata['Features'] = 'Auto Complete, Count creatives, Random Brand & Share creative'

### hooks to delete/modify html report #####
@pytest.mark.optionalhook
def pytest_metadata(metadata):
    metadata.pop("JAVA_HOME", None)
    metadata.pop("Plugins",None)